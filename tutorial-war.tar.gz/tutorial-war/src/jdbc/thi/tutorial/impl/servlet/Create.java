package jdbc.thi.tutorial.impl.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import jpa.thi.university.common.model.Room;

/**
 * Servlet implementation class Create
 */
@WebServlet("/jdbc/create")
public class Create extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Resource(lookup="java:jboss/datasources/University")
	DataSource dataSource;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
        Date date = new Date();
        
        final PrintWriter writer = response.getWriter();
        response.setContentType("text/html;charset=UTF-8");
        writer.println("<!Doctype html>");
        writer.println("<html><body>");
        writer.println(dateFormat.format(date));
        writer.println("<h1>JDBC Create</h1>");
        
        // Java-Raum Objekt erzeugen
        writer.println("<br/>" + this.persist(new Room(1, 1, 2, "G")));
        writer.println("<br/>" + this.persist(new Room(2, 2, 2, "G")));
        writer.println("<br/>" + this.persist(new Room(3, 3, 2, "G")));
        
        writer.println("</html></body>");
	}
	
	public Room persist(Room room) throws ServletException {
	    // SQL Statement zum Einfügen des Datensatzes
        String sql = "INSERT INTO Room(id, number, floor, building) VALUES(?, ?, ?, ?)";
        
	    /*
         * Connection
         *  aktive Verbindung über die DataSource
         *  
         * PreparedStatement
         *  Vorbereitetende Anweisung, welche eine SQL Anweisung ohne Paramter durchführt.
         *  Anschließend werden die Paramter gesetzt.
         */
        try (final Connection connection = dataSource.getConnection();
                PreparedStatement preparedStatement = connection.prepareStatement(sql)){
            
            preparedStatement.setInt(1, room.getId());
            preparedStatement.setInt(2, room.getNumber());
            preparedStatement.setInt(3, room.getFloor());
            preparedStatement.setString(4, room.getBuilding());
            
            // Ausführung eines Updates
            preparedStatement.executeUpdate();
            
        } catch (Exception e) {
            e.printStackTrace();
            throw new ServletException(e.getMessage());
        }
	    return room;
	}
}
