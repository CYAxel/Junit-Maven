package jdbc.thi.tutorial.impl.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

/**
 * Servlet implementation class Delete
 */
@WebServlet("/delete")
public class Delete extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Resource(lookup="java:jboss/datasources/University")
    DataSource dataSource;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
        Date date = new Date();
        
        final PrintWriter writer = response.getWriter();
        response.setContentType("text/html;charset=UTF-8");
        writer.println("<!Doctype html>");
        writer.println("<html><body>");
        writer.println(dateFormat.format(date));
        writer.println("<h1>JDBC Delete</h1>");
        
        int id = 1;
        writer.println("<h2>delete(" + id + ")</h2>");
        this.delete(id);
        writer.println("Room with id " + id + " got deleted");
        
        writer.println("</html></body>");
	}
	
	public void delete(int id) throws ServletException {
	    // SQL Statement zum Einfügen des Datensatzes
        String sql = "DELETE FROM Room WHERE id = ?";
        
        /*
         * Connection
         *  aktive Verbindung über die DataSource
         *  
         * PreparedStatement
         *  Vorbereitetende Anweisung, welche eine SQL Anweisung ohne Paramter durchführt.
         *  Anschließend werden die Paramter gesetzt.
         */
        try (final Connection connection = dataSource.getConnection();
                PreparedStatement preparedStatement = connection.prepareStatement(sql)){
            
            preparedStatement.setInt(1, id);
            
            // Ausführung eines Updates
            preparedStatement.executeUpdate();
            
        } catch (Exception e) {
            e.printStackTrace();
            throw new ServletException(e.getMessage());
        }
	}
}
