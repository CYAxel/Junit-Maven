package jdbc.thi.tutorial.impl.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

@WebServlet("/jdbc/connection")
public class TestConnection extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	/*
	 * DataSource durch Web-Container injizieren lassen
	 */
	@Resource(lookup="java:jboss/datasources/University")
	private DataSource dataSource;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
        Date date = new Date();
        
	    final PrintWriter writer = response.getWriter();
		response.setContentType("text/html;charset=UTF-8");
		writer.println("<!Doctype html>");
        writer.println("<html><body>");
        writer.println(dateFormat.format(date));
        writer.println("<h1>JDBC Connection</h1>");
        
        /*
         * Connection
         * Eine Connection wird aus der DataSource erzeugt
         *  und muss stets geschlossen werden!
         * 
         * Erzeugung:
         *      final Connection connection = dataSource.getConnection();
         * Schließen:
         *      connection.close()
         * 
         * Ab Java 7
         *      keyword try mit parameter,
         *      führt dazu, dass die Ressource stets geschlossen wird
         *      try(<Ressourcenzugriff>)
         *      
         *      siehe: http://javatricks.de/tricks/das-try-with-resources-statement
         */
        try (final Connection connection = dataSource.getConnection()){
            writer.println("Connection.isValid(): " + connection.isValid(10));
            
            DatabaseMetaData databaseMetaData = connection.getMetaData();
            
            writer.println("<h2>Version</h2>");
            writer.println("Major Version: " + databaseMetaData.getDatabaseMajorVersion());
            writer.println("<br/>Minor Version: " + databaseMetaData.getDatabaseMinorVersion());
            writer.println("<br/>Product Name: " + databaseMetaData.getDatabaseProductName());
            writer.println("<br/>Product Version: " + databaseMetaData.getDatabaseProductVersion());
            
            writer.println("<h2>Driver</h2>");
            writer.println("Driver Major Version: " + databaseMetaData.getDriverMajorVersion());
            writer.println("<br/>Driver Minor Version: " + databaseMetaData.getDriverMinorVersion());
            
            writer.println("<h2>Listing Tables</h2>");
            ResultSet result = databaseMetaData.getTables(null, null, "%", null);
            while(result.next()) {
                writer.println(result.getString("TABLE_NAME") + "<br/>");
            }
            
        } catch (Exception ex) {
            writer.println(ex.getMessage()+"\n");
            ex.printStackTrace(writer);
        }
        
        writer.println("</html></body>");
	}
	
}
