package jpa.thi.university.common.repository;

import java.util.List;

import javax.ejb.Local;

import jpa.thi.university.common.model.Student;

@Local
public interface StudentRepositoryLocal {
    public List<Student> getAll();
    public Student getById(int id);
    public Student create(Student s);
    public Student update(Student s);
    public void delete(Student s);
    public List<Student> getByFirstname(String firstname);
    public List<Student> getByLastname(String lastname);
    public List<Student> getByFirstnameLastname(String firstname, String lastname);
    public List<Student> getAll(boolean ascending);
    public List<Student> getByFirstnamePart(String part);
}
