package jpa.thi.university.common.repository;

import java.util.List;

import javax.ejb.Local;

import jpa.thi.university.common.model.Lecture;

@Local
public interface LectureRepositoryLocal {
    public List<Lecture> getAll();
    public Lecture getById(int id);    
    public Lecture create(Lecture l);
    public void delete(Lecture l);
    public Lecture update(Lecture l);
}
