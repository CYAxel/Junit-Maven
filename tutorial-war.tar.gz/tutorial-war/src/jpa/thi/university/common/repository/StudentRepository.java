package jpa.thi.university.common.repository;

import java.util.List;

import jpa.thi.university.common.model.Student;

public interface StudentRepository {
    public List<Student> getAll();
    public Student getById(int id);
    public Student merge(Student s);
    public void persist(Student s);
    public void remove(Student s);
    public List<Student> getByFirstname(String firstname);
    public List<Student> getByLastname(String lastname);
    public List<Student> getByFirstnameLastname(String firstname, String lastname);
    public List<Student> getAll(boolean ascending);
    public List<Student> getByFirstnamePart(String part);
}
