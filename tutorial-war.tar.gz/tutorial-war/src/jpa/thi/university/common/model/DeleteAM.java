package jpa.thi.university.common.model;

import java.io.IOException;
import java.io.PrintWriter;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.transaction.UserTransaction;

@WebServlet("/delete/am")
public class DeleteAM extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@PersistenceUnit
    private EntityManagerFactory entityManagerFactory;
    
    @Resource
    private UserTransaction userTransaction;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        
        final PrintWriter writer = response.getWriter();
        writer.println("<!Doctype html>");
        writer.println("<html><body>");
        writer.println("<h1>Delete - Application Managed</h1>");
        
        Student student = null;
        int studentId = 1;
        
        try {
            // Student finden
            student = entityManager.find(Student.class, studentId);
            
            // student löschen            
            userTransaction.begin();
            entityManager.remove(student);
            userTransaction.commit();
            
            writer.println("<br/>Student mit ID " + studentId + " wurde gelöscht");
        } catch(Exception e){
            try {
                userTransaction.rollback(); 
            } catch(Exception e1) {
                e.printStackTrace();
            }
            throw new ServletException(e.getMessage());
        }finally {
            entityManager.close();
        }
        writer.println("</html></body>");
	}

}
