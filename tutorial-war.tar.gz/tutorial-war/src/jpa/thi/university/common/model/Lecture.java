package jpa.thi.university.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;



/**
 * Schritte zur Erstellung einer Entity:
 * 1. Normale Klasse (class)
 * 2. Deklariert als Entität (@Entity)
 * 3. Implementiert Serializable (implements Serializable)
 * 4. Definierter Primärschlüssel (@Id)
 * 5. öffentlicher, leerer Constructor (public oder protected)
 * 
 * Annotation:  @Access(AccessType.<Typ>)
 * Entweder:    @Access(AccessType.FIELD)
 *  -> Persistence Provider greift auf Attribute zu
 *  -> Standard (wenn nichts angegeben ist)
 * Oder:        @Access(AccessType.PROPERTY)
 *  -> Persistence Provider greift auf Getter zu
 *  -> Vorteil: Theoretisch Logik in die Bean eingebaut werden
 * siehe: Salvanos, Alexander: Professionell entwickeln mit Java EE 7, Das umfassende Handbuch, S. 562
 */
@Entity
@Access(AccessType.FIELD)
public class Lecture implements Serializable{
    
    private static final long serialVersionUID = 1L;
    
    /*
     * @GeneratedValue(strategy = GenerationType.<Typ>
     * Automatische Generierung von IDs bei der Persistierung
     * Varianten:
     * 1. @GeneratedValue(strategy = GenerationType.IDENTITY)
     *  -> Erzeugung durch automatismen der Datenbankmanagementsysteme
     *  -> Unterscheidet sich starkt zwischen den Datenbankmanagementsystemen
     * 2. @GeneratedValue(strategy = GenerationType.SEQUENCE)
     *  -> Erzeugung durch einen Sequence-Generator
     *  -> Inkrementierung über spezielle Datenbanktrigger
     * 3. @GeneratedValue(strategy = GenerationType.TABLE)
     *  -> Primärschlüsselwert wird in eigener Datenbanktabelle eingetragen
     *  -> Datenbankmanagersystem-Hersteller unabhängig
     * 4. @GeneratedValue(strategy = GenerationType.AUTO) -> Standardwert
     *  -> JPA entscheidet, welche der 3 Stategien eingesetzt wird
     *  
     * siehe: Salvanos, Alexander: Professionell entwickeln mit Java EE 7, Das umfassende Handbuch, S. 573 ff.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    
    @Basic
    private String topic;
    
    @Basic
    private String description;
    
    /*
     * Zeitliche Basic-Attribute
     * 
     * Zusammenhang zwischen Datentypen und Annotation
     * 
     * 1. @Temporal(TemporalType.DATE)
     * 2. @Temporal(TemporalType.TIME)
     * 3. @Temporal(TemporalType.TIMESTAMP)
     * 
     * siehe: Salvanos, Alexander: Professionell entwickeln mit Java EE 7, Das umfassende Handbuch, S. 580
     */
    @Basic
    @Temporal(TemporalType.TIMESTAMP)
    private Date generated;
    
    /*
     * Transiente, nicht persistiertes Attribut
     * Attribut wird nicht persistiert (in der Datenbank abgelegt)
     * Attribut ist lediglich innerhalb der Java-Klasse vorhanden
     */
    @Transient
    private String comment;
    
    // Leerer Constructor
    public Lecture() {
        
    }
    
    /*
     * Constructor mit Attributen
     * Alle Attribute, außer id enthalten.
     * ID wird wegen @GeneratedValue autotisch beim Persistieren vergeben.
     */
    public Lecture(String topic, String description, String comment) {
        super();
        this.topic = topic;
        this.description = description;
        this.comment = comment;
        this.generated = new Date(); // aktuelles Datum
    }
    
    // Getter, da Attrbut private
    public int getId() {
        return id;
    }
    
    // Getter, da Attrbut private
    public String getTopic() {
        return topic;
    }

    // Getter, da Attrbut private
    public String getDescription() {
        return description;
    }
    
    // Getter, da Attrbut private
    public Date getGenerated() {
        return generated;
    }
    
    // Getter, da Attrbut private
    public String getComment() {
        return comment;
    }

    // toString für leichtere Ausgabe in der Servlets
    public String toString() {
        return this.topic + "; " + this.description + "generated at: " + this.generated;
    }

    /*
     * Identitätsprobleme bei Entitäten lösen
     * 
     * Eigentlich müsste bei einem Vergleich von zwei Entiäten stets folgendes gemacht werden:
     * 
     * if(this.getClass() == other.getClass() && this.getId().equals(oder.getId()) {
     *      return "Beide Objekte sind gleich"
     * }
     * Wir können allerdings auf Java-API automatischem zurückgreifen.
     */
    
    /*
     * hashCode()
     * Die Methode hashCode() berechnet zu dem Objekt, auf dem sie gerufen wird, einen Hash-Code.
     * Der Hash-Code ist ein integraler Wert, der verwendet wird, um Objekte in einem hash-
     * basierten Container abzulegen oder sie in einem solchen Container zu finden.
     * siehe: http://angelikalanger.com/Articles/EffectiveJava/03.HashCode/03.HashCode.html
     */
    @Override
    public int hashCode() {
        // erzeugt einen hashCode auf Basis der Objekt Id
        final int prime = 31;
        int result = 1;
        result = prime * result + id;
        return result;
    }
    
    /*
     * equals()
     * Objekte in Java kann man miteinander vergleichen, indem man die Methode equals() des einen
     * Objekts aufruft und das andere Objekt als Argument mitgibt. Das Ergebnis ist ein boolscher
     * Wert, der angibt, ob die beiden Objekte "gleich" sind. Ausnahmslos alle Klassen in Java
     * definieren diese Methode.  Die Implementierung der equals()-Methode ist entweder von der
     * Superklasse Object geerbt oder wurde in der betreffenden Klasse überschrieben. 
     * siehe: http://www.angelikalanger.com/Articles/EffectiveJava/02.Equals-Part2/02.Equals2.html
     */
    @Override
    public boolean equals(Object obj) {
        // führt verschiedene Vergleiche durch um zu sehen, ob beide Objekte identisch sind
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof Lecture)) {
            return false;
        }
        Lecture other = (Lecture) obj;
        if (id != other.id) {
            return false;
        }
        return true;
    }
}
