package jpa.thi.university.common.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Room implements Serializable{
    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @Id
    int id;
    
    int number;
    int floor;
    String building;
    
    public Room() { }
    
    public Room(int id, int number, int floor, String building) {
        super();
        this.id = id;
        this.number = number;
        this.floor = floor;
        this.building = building;
    }

    public int getId() {
        return id;
    }

    public int getNumber() {
        return number;
    }

    public int getFloor() {
        return floor;
    }

    public String getBuilding() {
        return building;
    }
    
    public String toString() {
        return "" + building + floor + String.format("%02d", number);
    }
        
}
