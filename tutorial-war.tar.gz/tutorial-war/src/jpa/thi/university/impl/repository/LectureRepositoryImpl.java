package jpa.thi.university.impl.repository;

import java.io.Serializable;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;
import javax.transaction.Transactional.TxType;

import jpa.thi.university.common.model.Lecture;
import jpa.thi.university.common.repository.LectureRepository;

public class LectureRepositoryImpl implements LectureRepository, Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    @PersistenceContext
    private EntityManager em;

    
    @SuppressWarnings("unchecked")
    @Override
    public List<Lecture> getAll() {
        Query query = em.createQuery("SELECT l FROM Lecture l");
        return query.getResultList();
    }

    @Override
    public Lecture getById(Long id) {
        Lecture l = em.find(Lecture.class, id);
        return l;
    }

    @Override
    @Transactional(TxType.REQUIRES_NEW)
    public Lecture merge(Lecture l) {
        return em.merge(l);
    }

    @Override
    @Transactional(TxType.REQUIRES_NEW)
    public void persist(Lecture l) {
        em.persist(l);
        em.flush();  
    }

    @Override
    public void remove(Lecture l) {
        em.remove(l);
    }

}
