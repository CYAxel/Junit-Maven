package jpa.thi.university.impl.repository;

import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import jpa.thi.university.common.model.Student;
import jpa.thi.university.common.repository.StudentRepositoryLocal;

@Stateless
@LocalBean
public class StudentRepository implements StudentRepositoryLocal {
    
    @PersistenceContext
    private EntityManager em;
    
    @Override
    public Student getById(int id){
        Student student = em.find(Student.class, id);
        return student;
    }
    
    @Override
    public List<Student> getAll(){
        TypedQuery<Student> query = em.createQuery("SELECT s FROM Student s", Student.class);
        return query.getResultList();
    }
    
    @Override
    public List<Student> getByFirstname(String firstname) {
        TypedQuery<Student> query = em.createQuery("SELECT s FROM Student s WHERE s.firstname = :firstname" , Student.class);
        //Benannte Parameter
        query.setParameter("firstname", firstname);
        return query.getResultList();
    }

    @Override
    public List<Student> getByLastname(String lastname) {
        TypedQuery<Student> query = em.createQuery("SELECT s FROM Student s WHERE s.lastname = ?1" , Student.class);
        // Positionsparameter
        query.setParameter(1, lastname);
        return query.getResultList();
    }

    @Override
    public List<Student> getByFirstnameLastname(String firstname, String lastname) {        
        TypedQuery<Student> query = em.createQuery(
                "SELECT s FROM Student s "
                + "WHERE s.firstname = :firstname "
                + "AND s.lastname = :lastname"
                , Student.class);
        query.setParameter("firstname", firstname);
        query.setParameter("lastname", lastname);
        return query.getResultList();
    }

    @Override
    public List<Student> getAll(boolean ascending) {
        String order = ascending ? "ASC" : "DESC";
        TypedQuery<Student> query = em.createQuery("SELECT s FROM Student s ORDER BY s.firstname " + order, Student.class);
        return query.getResultList();
    }

    @Override
    public List<Student> getByFirstnamePart(String part) {
        TypedQuery<Student> query = em.createQuery("SELECT s FROM Student s WHERE s.firstname LIKE :part", Student.class);
        query.setParameter("part", "%" + part + "%");
        return query.getResultList();
    }

    @Override
    public Student create(Student s) {
        em.persist(s);
        em.flush();
        return s;
    }

    @Override
    public Student update(Student s) {
        return em.merge(s);
    }

    @Override
    public void delete(Student s) {
        s = em.contains(s) ? s : em.merge(s);
        em.remove(s);;
    }
}
