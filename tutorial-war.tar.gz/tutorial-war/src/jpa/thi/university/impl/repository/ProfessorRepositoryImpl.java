package jpa.thi.university.impl.repository;

import java.io.Serializable;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import javax.transaction.Transactional.TxType;

import jpa.thi.university.common.model.Professor;
import jpa.thi.university.common.repository.ProfessorRepository;

public class ProfessorRepositoryImpl implements ProfessorRepository, Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    @PersistenceContext
    private EntityManager em;

    @Override
    public Professor getAll() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Professor getById(Long id) {
        Professor p = em.find(Professor.class, id);
        return p;
    }

    @Override
    @Transactional(TxType.REQUIRES_NEW)
    public Professor merge(Professor p) {
        return em.merge(p);
    }

    @Override
    @Transactional(TxType.REQUIRES_NEW)
    public void persist(Professor p) {
        em.persist(p);
        em.flush();  
    }

    @Override
    public void remove(Professor p) {
        em.remove(p);
    }

}
