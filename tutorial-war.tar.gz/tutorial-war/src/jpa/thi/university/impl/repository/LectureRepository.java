package jpa.thi.university.impl.repository;

import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import jpa.thi.university.common.model.Lecture;
import jpa.thi.university.common.repository.LectureRepositoryLocal;

@Stateless
@LocalBean
public class LectureRepository implements LectureRepositoryLocal {
    
    @PersistenceContext
    private EntityManager em;

    @Override
    public List<Lecture> getAll() {
        TypedQuery<Lecture> query = em.createQuery("SELECT l FROM Lecture l", Lecture.class);
        return query.getResultList();
    }

    @Override
    public Lecture getById(int id) {
        return em.find(Lecture.class, id);
    }

    @Override
    public Lecture create(Lecture l) {
        em.persist(l);
        em.flush();
        return l;
    }

    @Override
    public void delete(Lecture l) {
        l = em.contains(l) ? l : em.merge(l);
        em.remove(l);
    }

    @Override
    public Lecture update(Lecture l) {
        return em.merge(l);
    }

}
