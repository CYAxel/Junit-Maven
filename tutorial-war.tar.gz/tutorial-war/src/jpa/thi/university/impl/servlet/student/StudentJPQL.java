package jpa.thi.university.impl.servlet.student;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jpa.thi.university.common.model.Student;
import jpa.thi.university.common.repository.StudentRepository;

/**
 * Servlet implementation class StudentJPQL
 */
@WebServlet("/student/jpql")
public class StudentJPQL extends HttpServlet {
    
    @Inject
    StudentRepository studentRepository;
    
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
        Date date = new Date();
        
        final PrintWriter writer = response.getWriter();
        writer.println("<!Doctype html>");
        writer.println("<html><body>");
        writer.println(dateFormat.format(date));
        writer.println("<h1>Student JPQL</h1>");
        
        // JPQL aufrufen
        List<Student> students = null;
        String firstname = "Josef";
        String lastname = "Pursey";
        String part = "Jos";
        
        writer.println("<h2>getByFirstname</h2>");
        students = studentRepository.getByFirstname(firstname);
        writer.println("<br/>Found: " + students.size() + " Students with " + firstname);
        
        writer.println("<h2>getByLastname</h2>");
        students = studentRepository.getByLastname(lastname);
        writer.println("<br/>Found: " + students.size() + " Students with " + lastname);
        
        writer.println("<h2>getByFirstnameLastname</h2>");
        students = studentRepository.getByFirstnameLastname(firstname, lastname);
        writer.println("<br/>Found: " + students.size() + " Students with " + firstname + ", " + lastname);
        
        writer.println("<h2>getAll Ordered by Firstname</h2>");
        students = studentRepository.getAll(true);
        students.forEach((tmpStudent) -> {
            writer.println("<br/>" + tmpStudent.getId() + ": " + tmpStudent);
        });
        
        writer.println("<h2>getAll with part of firstname '" + part + "'</h2>");        
        students = studentRepository.getByFirstnamePart(part);
        students.forEach((tmpStudent) -> {
            writer.println("<br/>" + tmpStudent.getId() + ": " + tmpStudent);
        });
        
        writer.println("</html></body>");
	}

}
