package jpa.thi.university.impl.servlet.student;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jpa.thi.university.common.model.Lecture;
import jpa.thi.university.common.model.Student;
import jpa.thi.university.common.repository.LectureRepositoryLocal;
import jpa.thi.university.common.repository.StudentRepositoryLocal;

@WebServlet("/student/addlecture")
public class StudentAddLecture extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	@Inject
    StudentRepositoryLocal studentRepository;
	
	@Inject
	LectureRepositoryLocal lectureRepository;
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
        Date date = new Date();
        
        final PrintWriter writer = response.getWriter();
        response.setContentType("text/html;charset=UTF-8");
        writer.println("<!Doctype html>");
        writer.println("<html><body>");
        writer.println(dateFormat.format(date));
		writer.println("<h1>Student add Lecture</h1>");
		
		List<Lecture> allLectures = lectureRepository.getAll();
		Lecture lecture = allLectures.get(0);
		
		List<Student> students = studentRepository.getAll();
		Student student = students.get(0);
		
		List<Lecture> lectures = new ArrayList<Lecture>();
		lectures.add(lecture);
		
		student.setLectures(lectures);
		
		studentRepository.update(student);
        
		writer.println("Added Lecture: " + student.getLectures().get(0).getId() + ": " + student.getLectures().get(0));
		writer.println("<br/>to Student: " + student.getId() + ": " + student);
		writer.println("</html></body>");
		
	}

}
