package jpa.thi.university.impl.servlet.student;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jpa.thi.university.common.model.Student;
import jpa.thi.university.common.repository.StudentRepository;

/**
 * Servlet implementation class StudentCreate
 */
@WebServlet("/student/getall")
public class StudentGetAll extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	@Inject
	StudentRepository studentRepository;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
        Date date = new Date();
        
        final PrintWriter writer = response.getWriter();
        writer.println("<!Doctype html>");
        writer.println("<html><body>");
        writer.println(dateFormat.format(date));
        writer.println("<h1>Student Get All</h1>");
        
        List<Student> students = studentRepository.getAll();
        
        students.forEach((student) -> {
            writer.println("<br/>" + student.getId() + ": " + student);
        });
        
        writer.println("</body></html>");
	}

}
