package jpa.thi.university.impl.servlet.student;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jpa.thi.university.common.model.Address;
import jpa.thi.university.common.model.Student;
import jpa.thi.university.common.repository.StudentRepositoryLocal;

/**
 * Servlet implementation class StudentCreate
 */
@WebServlet("/student/create")
public class StudentCreate extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	@Inject
	StudentRepositoryLocal studentRepository;
	
	protected void doGet(HttpServletRequest request, 
	                     HttpServletResponse response)
	               throws ServletException, IOException {
	    DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
        Date date = new Date();
        
        final PrintWriter writer = response.getWriter();
        response.setContentType("text/html;charset=UTF-8");
        writer.println("<!Doctype html>");
        writer.println("<html><body>");
        writer.println(dateFormat.format(date));
		writer.println("<h1>Student Create</h1>");
		
		// Studenten + Addressen erzeugen
		Address a1 = new Address("Straße", "12", "85051", "Ingolstadt");
		List<Address> lA1 = new ArrayList<Address>();
		lA1.add(a1);
		Student studentJosef = new Student("Josef", "Pursey", "Josef.Pursey@org.de", lA1);
		
		Address a2 = new Address("Straße", "13", "85051", "Ingolstadt");
        List<Address> lA2 = new ArrayList<Address>();
        lA2.add(a2);
        Student studentStanley = new Student("Josef", "Willman", "Stanley.Willman@org.de", lA2);
        
        Address a3 = new Address("Straße", "14", "85051", "Ingolstadt");
        List<Address> lA3 = new ArrayList<Address>();
        lA3.add(a3);
        Student studentLucile = new Student("Lucile", "Summa", "Lucile.Summa@org.de", lA3);
		
        // Studenten persistieren
        studentRepository.create(studentJosef);
        studentRepository.create(studentStanley);
        studentRepository.create(studentLucile);
        
        writer.println("<br/>Created: " + studentJosef);
        writer.println("<br/>Created: " + studentStanley);
        writer.println("<br/>Created: " + studentLucile);
        
        writer.println("</body></html>");
    }

}
