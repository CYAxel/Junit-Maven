package jpa.thi.tutorial.impl.repository;

import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import javax.transaction.Transactional.TxType;

import jpa.thi.tutorial.common.repository.EntityManagerRepository;
import jpa.thi.university.common.model.Student;

public class EntityManagerRepositoryImpl implements EntityManagerRepository {
    /*
     * Entity Manager - Container Managed
     * Erzeugung und Verwaltung eines EntityManager durch den Container (CDI)
     * 
     * Annotation: @PersistenceContext(unitName="<Name der Persistence Unit>")
     * unitName kann entfallen, wenn lediglich eine Persistence Unit innerhalb der persitence.xml deklariert wurde
     */
    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public Map<String, Object> getProperties() {
        return entityManager.getProperties();
    }

    @Override
    public boolean isOpen() {
        return entityManager.isOpen();
    }
    
    /*
     * Transaktionssteuerung über Anntoation
     * Annotation: @Transactional(TxType.<Transaction Type>)
     */
    @Override
    @Transactional(TxType.REQUIRES_NEW)
    public Student persist(Student student) {
        entityManager.persist(student);
        return student;
    }

}
