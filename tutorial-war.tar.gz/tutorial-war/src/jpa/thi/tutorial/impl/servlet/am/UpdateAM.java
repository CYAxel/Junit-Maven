package jpa.thi.tutorial.impl.servlet.am;

import java.io.IOException;
import java.io.PrintWriter;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.transaction.UserTransaction;

import jpa.thi.university.common.model.Student;

/**
 * Servlet implementation class UpdateAM
 */
@WebServlet("/update/am")
public class UpdateAM extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@PersistenceUnit
    private EntityManagerFactory entityManagerFactory;
    
    @Resource
    private UserTransaction userTransaction;
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    EntityManager entityManager = entityManagerFactory.createEntityManager();
        
        final PrintWriter writer = response.getWriter();
        response.setContentType("text/html;charset=UTF-8");
        writer.println("<!Doctype html>");
        writer.println("<html><body>");
        writer.println("<h1>Update - Application Managed</h1>");
        
        Student student = null;
        int studentId = 1;
        
        try {
            // Student finden
            student = entityManager.find(Student.class, studentId);
            writer.println("<br/>Vor Änderung:" + student.getId() + ": " + student);
            
            // Student verändern
            // Java Objekt
            student.setFirstname("Galen");
            
            userTransaction.begin();
            // in Datenbank aktualisieren
            entityManager.merge(student);
            userTransaction.commit();
            
            // Student erneut aus Persistenz holen
            student = entityManager.find(Student.class, studentId);
            writer.println("<br/>Nach Änderung:" + student.getId() + ": " + student);
            
        } catch(Exception e){
            try {
                userTransaction.rollback(); 
            } catch(Exception e1) {
                e.printStackTrace();
            }
            throw new ServletException(e.getMessage());
        }finally {
            entityManager.close();
        }
        
        writer.println("</html></body>");
	}

}
