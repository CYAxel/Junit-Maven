package jpa.thi.tutorial.impl.servlet.am;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.transaction.UserTransaction;

import jpa.thi.university.common.model.Address;
import jpa.thi.university.common.model.Student;

/**
 * Servlet implementation class TransactionCreate
 */
@WebServlet("/transaction/am")
public class TransactionAM extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	@PersistenceUnit
    private EntityManagerFactory entityManagerFactory;
	
	/*
	 * Transaction
	 * Anntotation: @Resource
	 * 
	 * Durch den Container wird eine UserTransaction erzeugt.
	 * Die User Transaction kann durch begin(), commit() und rollback() verwendet werden.
	 */
	@Resource
    private UserTransaction userTransaction;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    // Erzeugung + Öffnen des EntityManager
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        
        final PrintWriter writer = response.getWriter();
        response.setContentType("text/html;charset=UTF-8");
        writer.println("<!Doctype html>");
        writer.println("<html><body>");
        writer.println("<h1>Transaction (Entity Manager) Application Managed</h1>");
        
        // Erzegung eines Studenten + Adresse
        Address address = new Address("Manchinger Straße", "20a", "85051", "Ingolstadt");
        List<Address> addresses = new ArrayList<Address>();
        addresses.add(address);
        Student student = new Student("Max", "Mustermann", "Max.Mustermann@max.de", addresses);
        
        try {
            // startet eine Transaktion
            userTransaction.begin();
            entityManager.persist(student);
            // schließt eine Transaktion
            userTransaction.commit();
        } catch(Exception e){ // Fehlerfall
            try {
                // macht die Transaktion Rückgängig
                userTransaction.rollback(); 
            } catch(Exception e1) {
                e.printStackTrace();
            }
            throw new ServletException(e.getMessage());
        }finally {
            entityManager.close();
        }
        writer.println("<br/>Student erfolgreich angelegt");
        writer.println("<br/>Automatisch erzeugte ID: " + student.getId());
        writer.println("<br/>" + student);
        writer.println("</html></body>");
	}

}
