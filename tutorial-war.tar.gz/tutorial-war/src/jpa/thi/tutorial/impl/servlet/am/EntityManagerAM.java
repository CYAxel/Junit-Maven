package jpa.thi.tutorial.impl.servlet.am;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/entitymanager/am")
public class EntityManagerAM extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	/*
     * Entity Manager - Application Managed
     * Erzeugung eines EntityManager innerhalb eines Servlet über eine EntityManagerFactory
     * 
     * Hinweis: Bei Servlets muss der EntityManger immer selbst ereugt und geschlossen (= Application Managed)
     * werden, damit es maximal eine Instanz des EntityManagers gibt. Der Entity Manager ist nicht Thread sicher,
     * allerdings können Servlets von mehreren Threads aufgerufen werden.
     * 
     * Annotation: @PersistenceUnit(unitName="<Name der Persistence Unit>")
     * unitName kann entfallen, wenn lediglich eine Persistence Unit innerhalb der persitence.xml deklariert wurde
     */
    @PersistenceUnit
    private EntityManagerFactory entityManagerFactory;
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    // Erzeugung + Öffnen des EntityManager
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        
        final PrintWriter writer = response.getWriter();
        response.setContentType("text/html;charset=UTF-8");
        writer.println("<!Doctype html>");
        writer.println("<html><body>");
        
        writer.println("<h1>Entity Manager Application Managed</h1>");
        writer.println("<br/>Connected: " +  entityManager.isOpen());
        Map<String, Object> props = entityManager.getProperties();
        props.forEach((key, value) -> {
            writer.println("<br/>" + key + ": " + value);
        });
        
        writer.println("</html></body>");
        
        // Schließen des EntityManager
        entityManager.close();
	}

}
