package jpa.thi.tutorial.impl.servlet.am;

import java.io.IOException;
import java.io.PrintWriter;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jpa.thi.university.common.model.Student;

@WebServlet("/read/am")
public class ReadAM extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@PersistenceUnit
    private EntityManagerFactory entityManagerFactory;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    EntityManager entityManager = entityManagerFactory.createEntityManager();
        
        final PrintWriter writer = response.getWriter();
        writer.println("<!Doctype html>");
        writer.println("<html><body>");
        writer.println("<h1>Read - Application Managed</h1>");
        
        Student student = null;
        int studentId = 1;
        
        try {
            student = entityManager.find(Student.class, studentId);
            writer.println("<br/>Student mit ID: " + studentId + " gefunden");
            writer.println("<br/>" + student.getId() + ": " + student);
        } catch(Exception e){
            throw new ServletException(e.getMessage());
        }finally {
            entityManager.close();
        }
        
        writer.println("</html></body>");
	}

}
