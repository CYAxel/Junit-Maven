package test;

import static org.junit.Assert.*;
import jpa.thi.university.common.model.Address;

import org.junit.Test;

public class Addresstest {

	@Test
	 public void TestAddress() {
	     Address addr1 = new Address("Münchenerstraße", "7", "85015", "Ingolstadt");
	     assertEquals("Münchenerstraße", addr1.getStreet());
	     assertEquals ("7",addr1.getHouseNumber());
	     assertEquals ("85015",addr1.getPostalCode());
	     assertEquals ("Ingolstadt",addr1.getCity());
	     assertEquals("Münchenerstraße 7 85015 Ingolstadt", addr1.toString());

	 }
}


