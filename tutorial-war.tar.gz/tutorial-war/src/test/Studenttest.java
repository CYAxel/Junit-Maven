package test;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Test;

import com.sun.xml.internal.bind.v2.schemagen.xmlschema.List;

import jpa.thi.university.common.model.Student;

public class Studenttest {

    @Test
    public void testStudent() {
        Student stu = new Student();
        assertNotNull (stu.getId());
        assertNotNull (stu.getFirstname());
        assertNotNull (stu.getLastname());
        assertNotNull (stu.getEmail());  
        assertNotNull (stu.toString());
    }
    public void testgetAddresses(){
    
        Student stu = new Student(); 
        List<Address> addrelist = new ArrayList<>();
        stu.setLectures(addrelist);
        assertNotNull (stu.setLectures(addrelist));
    }
    public void testgetgetLectures(){
        Student stu = new Student();
        List<Lecture> lectureList = new ArrayList<>();
        stu.setLectures(lectureList);
        assertNotNull (stu.setLectures(lectureList));
    }
    public void testset(){
        Student stu = new Student();
        setFirtstname setF = new setFirstname();
        stu.setFirstname(setF);
        assertNotNull (stu.setFirstname(setF));
    }

}
