package test;

import static org.junit.Assert.*;

import java.util.List;
import java.util.ArrayList;

import org.junit.Test;

import jpa.thi.university.common.model.Address;
import jpa.thi.university.common.model.Lecture;
import jpa.thi.university.common.model.Student;

public class Studenttest {

    @Test
    public void testStudent() {
        List<Address> lA1 = new ArrayList<Address>();  
        Student stu = new Student("Josef","Pursey","Josef.Pursey@org.de",lA1);
        
        assertNotNull (stu.getFirstname());
        assertNotNull (stu.getLastname());
        assertNotNull (stu.getEmail());  
        assertNotNull (stu.toString());
    }
    @Test
    public void testgetAddresses(){
    
        Student stu = new Student(); 
        List<Address> addrelist = new ArrayList<Address>();
        stu.setAddresses(addrelist);
        assertNotNull (stu.getAddresses());
    }
    @Test
    public void testgetgetLectures(){
        Student stu = new Student();
        List<Lecture> lectureList = new ArrayList<Lecture>();
        stu.setLectures(lectureList);
        assertNotNull (stu.getLectures());
    }
    @Test
    public void testset(){
        Student stu = new Student();
        String firstname = "MyName";
        stu.setFirstname(firstname);
        assertNotNull (stu.getFirstname());
    }

}
