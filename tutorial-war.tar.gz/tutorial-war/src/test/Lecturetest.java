package test;

import static org.junit.Assert.*;

import org.junit.Test;

import jpa.thi.university.common.model.Address;
import jpa.thi.university.common.model.Lecture;

public class Lecturetest {

    @Test
    public void testLecture() {
        Lecture lec = new Lecture();
        assertNotNull (lec.getId());
        assertNotNull (lec.getTopic());
        assertNotNull (lec.getDescription());
        assertNotNull (lec.getGenerated());
        assertNotNull (lec.getComment());
        assertNotNull (lec.toString());
                
    }
    public void testhashCode() {
        Lecture lec2 = new Lecture();
        int Code = lec2.hashCode();
        int id = 5;
        assertEquals (36,Code);
        
    }
    public void testequals() {
        Lecture lec3 = new Lecture();
        Lecture lec4 = new Lecture();
        assert lec3.equals(lec4);
    }  
}
