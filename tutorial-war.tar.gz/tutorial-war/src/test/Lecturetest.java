package test;

import static org.junit.Assert.assertNotNull;

import javax.inject.Inject;

import org.junit.Test;

import jpa.thi.university.common.model.Lecture;
import jpa.thi.university.common.repository.LectureRepositoryLocal;

public class Lecturetest {

    @Test
    public void testLecture() {
        Lecture lec = new Lecture();
        assertNotNull (lec.getId());
        assertNotNull (lec.getTopic());
        assertNotNull (lec.getDescription());
        assertNotNull (lec.getGenerated());
        assertNotNull (lec.getComment());
        assertNotNull (lec.toString());
                
    }
}
