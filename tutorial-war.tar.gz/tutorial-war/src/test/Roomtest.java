package test;

import static org.junit.Assert.*;

import org.junit.Test;

import jpa.thi.university.common.model.Room;

public class Roomtest {

    @Test
    public void testRoom() {
        Room ro = new Room();
        assertNotNull (ro.getId());
        assertNotNull (ro.getNumber());
        assertNotNull (ro.getFloor());
        assertNotNull (ro.getBuilding());
        assertNotNull (ro.toString());
    }
}
