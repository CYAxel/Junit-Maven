package test;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Test;

import com.sun.xml.internal.bind.v2.schemagen.xmlschema.List;

import jpa.thi.university.common.model.Address;
import jpa.thi.university.common.model.Professor;

public class Professortest<Lecture> {

    @Test
    public void testProfessor() {
            Professor prof= new Professor();
            assertNotNull (prof.getId());
            assertNotNull (prof.getTitle());
            assertNotNull (prof.getFirstName());
            assertNotNull (prof.getLastName());
            assertNotNull (prof.getLectures());
            List<Lecture> lectureList = new ArrayList<>();
            prof.setLectures(lectureList);
            assertNotNull (prof.setLectures(lectureList));
            assertNotNull (prof.toString());
        };
        public void testhasCode () {
            Professor prof2 = new Professor();
            
            int Code = prof2.hashCode();
            int id =5;
            assertEquals(36,Code);
            
        };
        
        public void testequals() {
            Professor prof3 = new Professor();
            Professor prof4 = new Professor();
            assert prof3.equals(prof4);
        }
    }


