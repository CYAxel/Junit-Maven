package MavenMockito.Mockito_tutorial;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.BeforeClass;
import org.junit.Test;

import jpa.thi.university.common.model.Address;
import jpa.thi.university.common.model.Student;

public class StudentDALTest {
    
    private static StudentDAL mockedStudentDAL;
    private static Student student1;
    private static Student student2;
    @BeforeClass
    public static void setUp(){
      //Create mock object of BookDAL
      mockedStudentDAL = mock(StudentDAL.class);
      List<Address> addrlist1 = new ArrayList<Address>();
     
   
      //Create few instances of Book class.
      student1 = new Student("firstname1","lastname1","Email1",addrlist1);
   
      
      
   
      //Stubbing the methods of mocked BookDAL with mocked data. 
      when(mockedStudentDAL.getAllStudents()).thenReturn(Arrays.asList(student1, student2));
      when(mockedStudentDAL.getStudent(student1)).thenReturn(student1);
      when(mockedStudentDAL.createStudent(student1)).thenReturn(student1.getId());
      when(mockedStudentDAL.updateStudent(student1)).thenReturn(student1.getId());
    }
    
    @Test
    public void testgetAllStudent() throws Exception {
        List<Address> addrlist = new ArrayList<Address>();
        List<Student> allStudents = mockedStudentDAL.getAllStudents();
        Student mystudent = allStudents.get(0);
        assertNotNull(mystudent);
        assertEquals("firstname1", mystudent.getFirstname());
        assertEquals("lastname1", mystudent.getLastname());
        assertEquals("Email1", mystudent.getEmail());
        assertEquals(addrlist, mystudent.getAddresses());
    }
      @Test
      public void testgetStudent(){
     
        Student mystudent = mockedStudentDAL.getStudent(student1);
        List<Address> addrlist = new ArrayList<Address>();
        assertNotNull(mystudent);
        assertEquals("firstname1", mystudent.getFirstname());
        assertEquals("lastname1", mystudent.getLastname());
        assertEquals("Email1", mystudent.getEmail());
        assertEquals(addrlist, mystudent.getAddresses());
      }
     
      @Test
      public void testcreateStudent(){
        int id = mockedStudentDAL.createStudent(student1);
        assertNotNull(id);
        assertEquals(student1.getId(), id);
      }
     
      @Test
      public void testupdateStudent(){
     
        int id = mockedStudentDAL.updateStudent(student1);
        assertNotNull(id);
        assertEquals(student1.getId(), id);
      }
}
    

