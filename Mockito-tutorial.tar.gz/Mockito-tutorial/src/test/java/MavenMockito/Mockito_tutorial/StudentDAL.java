package MavenMockito.Mockito_tutorial;

import java.util.Collections;
import java.util.List;

import jpa.thi.university.common.model.Student;

public class StudentDAL {
    
    private static StudentDAL studentDAL = new StudentDAL();
    public List<Student> getAllStudents(){
        return Collections.emptyList();
    }
   
   
    public Student getStudent(Student id){
        return null;
    }
   
    public int createStudent(Student student){
        return student.getId();
    }
   
    public int updateStudent(Student student){
        return student.getId();
    }
   
    public static StudentDAL getInstance(){
        return studentDAL;
    }

}
