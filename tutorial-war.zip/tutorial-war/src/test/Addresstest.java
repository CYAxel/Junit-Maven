package test;

import static org.junit.Assert.*;
import jpa.thi.university.common.model.Address;
import jpa.thi.university.common.model.Address.*;

import org.junit.Test;

public class Addresstest {

	@Test
	public void testAddress() {
		Address addr= new Address();
		assertNotNull (addr.getId());
        assertNotNull (addr.getStreet());
		assertNotNull (addr.getHouseNumber());
		assertNotNull (addr.getPostalCode());
		assertNotNull (addr.getCity());
	};
	public void testhasCode () {
		Address addr2 = new Address();
		
		int Code = addr2.hashCode();
		int id =3;
		assertEquals(34,Code);
		
	};
	
	public void testequals() {
		Address addr3 = new Address();
		Address addr4 = new Address();
		assert addr3.equals(addr4);
	}
}


