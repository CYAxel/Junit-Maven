package jdbc.thi.tutorial.impl.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import jpa.thi.university.common.model.Room;

@WebServlet("/select")
public class Select extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Resource(lookup="java:jboss/datasources/Tutorial")
    DataSource dataSource;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
        Date date = new Date();
        
        final PrintWriter writer = response.getWriter();
        response.setContentType("text/html;charset=UTF-8");
        writer.println("<!Doctype html>");
        writer.println("<html><body>");
        writer.println(dateFormat.format(date));
        writer.println("<h1>JDBC Select</h1>");
        
        writer.println("<h2>getAll()</h2>");
        List<Room> rooms = this.getAll();
        rooms.forEach((room) -> {
            writer.println("<br/>" + room);
        });
        
        writer.println("<h2>findById(1)</h2>");
        writer.println("<br/>" + this.getById(1));
        
        writer.println("</html></body>");
	}
	
	public Room getById(int id) throws ServletException {
	    // SQL Statement zum Einfügen des Datensatzes
        String sql = "SELECT r.* FROM University.Room r WHERE r.id = ?";
        
        /*
         * Connection
         *  aktive Verbindung über die DataSource
         *  
         * PreparedStatement
         *  Vorbereitetende Anweisung, welche eine SQL Anweisung ohne Paramter durchführt.
         *  Anschließend werden die Paramter gesetzt.
         */
        try (final Connection connection = dataSource.getConnection();
                PreparedStatement preparedStatement = connection.prepareStatement(sql)){
            
            // id zum PreparedStatement setzen
            preparedStatement.setInt(1, id);
            
            // Ausführung eines Updates
            preparedStatement.executeQuery();
            
            ResultSet resultSet = preparedStatement.getResultSet();
            if(resultSet.next()) {
                return new Room(resultSet.getInt("id"), resultSet.getInt("number"), resultSet.getInt("floor"), resultSet.getString("building"));
            } else {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new ServletException(e.getMessage());
        }
	}
	
	public List<Room> getAll() throws ServletException {
	    // SQL Statement zum Einfügen des Datensatzes
        String sql = "SELECT * FROM University.Room";
        // Temporäre Java Room Objekte für Zuweisung
        List<Room> rooms = new ArrayList<Room>();
        
	    /*
         * Connection
         *  aktive Verbindung über die DataSource
         *  
         * PreparedStatement
         *  Vorbereitetende Anweisung, welche eine SQL Anweisung ohne Paramter durchführt.
         *  Anschließend werden die Paramter gesetzt.
         */
        try (final Connection connection = dataSource.getConnection();
                PreparedStatement preparedStatement = connection.prepareStatement(sql)){
            
            // Ausführung eines Updates
            preparedStatement.executeQuery();
            
            ResultSet resultSet = preparedStatement.getResultSet();
            while(resultSet.next()) {
                rooms.add(new Room(resultSet.getInt("id"), resultSet.getInt("number"), resultSet.getInt("floor"), resultSet.getString("building")));
            }
            return rooms;
        } catch (Exception e) {
            e.printStackTrace();
            throw new ServletException(e.getMessage());
        }
	}
}
