package jdbc.thi.tutorial.impl.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import jpa.thi.university.common.model.Room;

/**
 * Servlet implementation class Transaction
 */
@WebServlet("/transaction")
public class Transaction extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Resource(lookup="java:jboss/datasources/Tutorial")
    DataSource dataSource;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
        Date date = new Date();
        
        final PrintWriter writer = response.getWriter();
        response.setContentType("text/html;charset=UTF-8");
        writer.println("<!Doctype html>");
        writer.println("<html><body>");
        writer.println(dateFormat.format(date));
        writer.println("<h1>JDBC Create</h1>");
        
        writer.println("Created:");
        List<Room> rooms = this.create();
        rooms.forEach((room) -> {
            writer.println("<br/>" + room);
        });
        
        writer.println("</html></body>");
	}
	
	public List<Room> create() throws ServletException {
	 // SQL Statement zum Einfügen des Datensatzes
        String sql = "INSERT INTO University.Room(id, number, floor, building) VALUES(?, ?, ?, ?)";
        
        List<Room> rooms = new ArrayList<Room>();
        Room room1 = new Room(1, 1, 2, "B");
        Room room2 = new Room(2, 2, 2, "B");
        Room room3 = new Room(3, 3, 2, "B");
        
        /*
         * Connection
         *  aktive Verbindung über die DataSource
         *  
         * PreparedStatement
         *  Vorbereitetende Anweisung, welche eine SQL Anweisung ohne Paramter durchführt.
         *  Anschließend werden die Paramter gesetzt.
         */
        try (final Connection connection = dataSource.getConnection();
                PreparedStatement preparedStatement1 = connection.prepareStatement(sql);
                PreparedStatement preparedStatement2 = connection.prepareStatement(sql);
                PreparedStatement preparedStatement3 = connection.prepareStatement(sql)){
            
            // Autocommit auf manuellen COMMIT umschalten
            connection.setAutoCommit(false);
            
            // Room 1
            preparedStatement1.setInt(1, room1.getId());
            preparedStatement1.setInt(2, room1.getNumber());
            preparedStatement1.setInt(3, room1.getFloor());
            preparedStatement1.setString(4, room1.getBuilding());
            // Room 2
            preparedStatement2.setInt(1, room2.getId());
            preparedStatement2.setInt(2, room2.getNumber());
            preparedStatement2.setInt(3, room2.getFloor());
            preparedStatement2.setString(4, room2.getBuilding());
            // Room 3
            preparedStatement3.setInt(1, room3.getId());
            preparedStatement3.setInt(2, room3.getNumber());
            preparedStatement3.setInt(3, room3.getFloor());
            preparedStatement3.setString(4, room3.getBuilding());
            
            // Ausführung eines Updates
            preparedStatement1.executeUpdate();
            preparedStatement2.executeUpdate();
            preparedStatement3.executeUpdate();
            
            rooms.add(room1);
            rooms.add(room2);
            rooms.add(room3);
            
            // Transaktion abschließen
            connection.commit();
        } catch (Exception e) {
            e.printStackTrace();
            throw new ServletException(e.getMessage());
        }
        return rooms;
	}
}
