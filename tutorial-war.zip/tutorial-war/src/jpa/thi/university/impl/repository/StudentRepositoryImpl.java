package jpa.thi.university.impl.repository;

import java.io.Serializable;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;
import javax.transaction.Transactional.TxType;

import jpa.thi.university.common.model.Student;
import jpa.thi.university.common.repository.StudentRepository;

public class StudentRepositoryImpl implements StudentRepository, Serializable{
    
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    @PersistenceContext
    private EntityManager em;
    
    @Transactional(TxType.REQUIRES_NEW)
    public void persist(Student student){
        em.persist(student);
        em.flush();    
    }
    
    @Transactional(TxType.REQUIRES_NEW)
    public Student merge(Student student){
        return em.merge(student);
    }
    
    @Transactional(TxType.REQUIRES_NEW)
    public void remove(Student student){
        // em.remove(student);
        /*
         * Nachdem über ein Servlet Injected wird,
         * ist der Persistence Context für jede Anfrage
         * neu, deshalb muss ein merge ausgeführt werden
         */
        em.remove(em.contains(student) ? student : em.merge(student));
    }
    
    public Student getById(int id){
        Student student = em.find(Student.class, id);
        return student;
    }
    
    public List<Student> getAll(){
        TypedQuery<Student> query = em.createQuery("SELECT s FROM Student s", Student.class);
        return query.getResultList();
    }
    
    public List<Student> getByFirstname(String firstname) {
        TypedQuery<Student> query = em.createQuery("SELECT s FROM Student s WHERE s.firstname = :firstname" , Student.class);
        //Benannte Parameter
        query.setParameter("firstname", firstname);
        return query.getResultList();
    }

    @Override
    public List<Student> getByLastname(String lastname) {
        TypedQuery<Student> query = em.createQuery("SELECT s FROM Student s WHERE s.lastname = ?1" , Student.class);
        // Positionsparameter
        query.setParameter(1, lastname);
        return query.getResultList();
    }

    @Override
    public List<Student> getByFirstnameLastname(String firstname, String lastname) {        
        TypedQuery<Student> query = em.createQuery(
                "SELECT s FROM Student s "
                + "WHERE s.firstname = :firstname "
                + "AND s.lastname = :lastname"
                , Student.class);
        query.setParameter("firstname", firstname);
        query.setParameter("lastname", lastname);
        return query.getResultList();
    }

    @Override
    public List<Student> getAll(boolean ascending) {
        String order = ascending ? "ASC" : "DESC";
        TypedQuery<Student> query = em.createQuery("SELECT s FROM Student s ORDER BY s.firstname " + order, Student.class);
        return query.getResultList();
    }

    @Override
    public List<Student> getByFirstnamePart(String part) {
        TypedQuery<Student> query = em.createQuery("SELECT s FROM Student s WHERE s.firstname LIKE :part", Student.class);
        query.setParameter("part", "%" + part + "%");
        return query.getResultList();
    }
}
