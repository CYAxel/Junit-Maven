package jpa.thi.university.impl.servlet.professor;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jpa.thi.university.common.model.Professor;
import jpa.thi.university.common.repository.ProfessorRepository;

/**
 * Servlet implementation class StudentCreate
 */
@WebServlet("/professor/create")
public class ProfessorCreate extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	@Inject
    ProfessorRepository professorRepository;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
        Date date = new Date();
        
        final PrintWriter writer = response.getWriter();
        writer.println("<!Doctype html>");
        writer.println("<html><body>");
        writer.println(dateFormat.format(date));
		writer.println("<h1>Professor Create</h1>");
		
		Professor professor = new Professor("Prof. Dr.", "Jeff", "Bonier");
        
		professorRepository.persist(professor);
        
		writer.println("Created: " + professor);
		writer.println("</html></body>");
		
	}

}
