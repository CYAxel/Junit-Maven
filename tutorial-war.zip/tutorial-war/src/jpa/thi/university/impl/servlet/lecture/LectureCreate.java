package jpa.thi.university.impl.servlet.lecture;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jpa.thi.university.common.model.Lecture;
import jpa.thi.university.common.repository.LectureRepository;

/**
 * Servlet implementation class StudentCreate
 */
@WebServlet("/lecture/create")
public class LectureCreate extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	@Inject
    LectureRepository lectureRepository;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LectureCreate() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
        Date date = new Date();
        
        final PrintWriter writer = response.getWriter();
        writer.println("<!Doctype html>");
        writer.println("<html><body>");
        writer.println(dateFormat.format(date));
		writer.println("<h1>Lecture Create</h1>");
		
		Lecture lecture = new Lecture("Java EE Basics", "This lecture specifies ...", "comment");
		
		lectureRepository.persist(lecture);
		writer.println("Created: " + lecture);
        
		writer.println("</html></body>");
		
	}

}
