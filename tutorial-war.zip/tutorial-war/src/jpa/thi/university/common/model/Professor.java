package jpa.thi.university.common.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
@Access(AccessType.FIELD)
public class Professor implements Serializable{    
    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    
    private String title;
    private String firstName;
    private String lastName;
    
    @OneToMany
    private List<Lecture> lectures;
    
    public Professor() {
        
    }
    
    public Professor(String title, String firstName, String lastName) {
        super();
        this.title = title;
        this.firstName = firstName;
        this.lastName = lastName;
        this.lectures = null;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public List<Lecture> getLectures() {
        return lectures;
    }

    public void setLectures(List<Lecture> lectures) {
        this.lectures = lectures;
    }
    
    public String toString() {
        return this.title + " " + this.firstName + " " + this.lastName;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + id;
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof Professor)) {
            return false;
        }
        Professor other = (Professor) obj;
        if (id != other.id) {
            return false;
        }
        return true;
    }
}
