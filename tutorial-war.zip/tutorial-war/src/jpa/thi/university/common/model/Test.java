package jpa.thi.university.common.model;

import static org.junit.Assert.*;
import jpa.thi.university.common.model.*;
 

public class Test {

	@org.junit.Test
	public void test() {
		    assertNotNull (id);
			assertNotNull (street);
			assertNotNull (houseNumber);
			assertNotNull (postalCode);
			assertNotNull (city);
		};
		
		public void testhasCode () {
			assertequals (33, new hashCode(). id==2);
		};
		
		public void testboolean (Object obj) {
			assertTrue (this == obj);
			assertFalse (obj == null);
			assertFalse (!(obj instanceof Address));
			
		};

	}



