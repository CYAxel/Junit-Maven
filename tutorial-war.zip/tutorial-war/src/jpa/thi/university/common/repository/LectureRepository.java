package jpa.thi.university.common.repository;

import java.util.List;

import jpa.thi.university.common.model.Lecture;

public interface LectureRepository {
    public List<Lecture> getAll();
    public Lecture getById(Long id);
    public Lecture merge(Lecture l);
    public void persist(Lecture l);
    public void remove(Lecture l);
}
