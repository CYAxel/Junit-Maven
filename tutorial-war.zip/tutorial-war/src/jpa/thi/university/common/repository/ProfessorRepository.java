package jpa.thi.university.common.repository;

import jpa.thi.university.common.model.Professor;

public interface ProfessorRepository {
    public Professor getAll();
    public Professor getById(Long id);
    public Professor merge(Professor p);
    public void persist(Professor p);
    public void remove(Professor p);
}
