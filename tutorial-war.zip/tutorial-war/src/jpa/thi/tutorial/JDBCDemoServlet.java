package jpa.thi.tutorial;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

/**
 * Servlet implementation class WildFlyDemoServlet
 */
@WebServlet("/JDBCDemoServlet")
public class JDBCDemoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    @Resource(lookup="java:jboss/datasources/MySqlThidbDS")
    private DataSource ds;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    final PrintWriter out = response.getWriter();
        response.setContentType("text/html;charset=UTF-8");
        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<body>");
        try (final Connection con = ds.getConnection()){
            DatabaseMetaData databaseMetaData = con.getMetaData();
            
            out.println("<h1>Version</h1>");
            out.println("Major Version: " + databaseMetaData.getDatabaseMajorVersion());
            out.println("<BR>Minor Version: " + databaseMetaData.getDatabaseMinorVersion());
            out.println("<BR>Product Name: " + databaseMetaData.getDatabaseProductName());
            out.println("<BR>Product Version: " + databaseMetaData.getDatabaseProductVersion());
            
            out.println("<BR><h1>Driver</h1>");
            out.println("Driver Major Version: " + databaseMetaData.getDriverMajorVersion());
            out.println("<BR>Driver Minor Version: " + databaseMetaData.getDriverMinorVersion());
            
            out.println("<BR><h1>Listing Tables</h1>");
            ResultSet result = databaseMetaData.getTables(null, null, null, null);
            while(result.next()) {
                out.println("<BR>" + result.getString(3));
            }
            
            out.println("<BR><h1>Primary Key for Table</h1>");
            result = databaseMetaData.getPrimaryKeys(null, null, "customer");

            while(result.next()){
                out.println("<BR>" + result.getString(4));
            }
            
        } catch (Exception ex) {
            out.println(ex.getMessage()+"\n");
            ex.printStackTrace(out);
        }
        out.println("</body></html>");
	}

}
