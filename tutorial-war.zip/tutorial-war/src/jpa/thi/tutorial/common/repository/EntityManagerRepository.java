package jpa.thi.tutorial.common.repository;

import java.util.Map;

import jpa.thi.university.common.model.Student;

public interface EntityManagerRepository {
    public Map<String, Object> getProperties();
    public boolean isOpen();
    public Student persist(Student student);
}
