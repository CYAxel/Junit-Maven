package jpa.thi.tutorial.impl.servlet.am;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.transaction.UserTransaction;

import jpa.thi.university.common.model.Address;
import jpa.thi.university.common.model.Student;

@WebServlet("/flush/AM")
public class FlushAM extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@PersistenceUnit
    private EntityManagerFactory entityManagerFactory;
    
    @Resource
    private UserTransaction userTransaction;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    EntityManager entityManager = entityManagerFactory.createEntityManager();
        
        final PrintWriter writer = response.getWriter();
        writer.println("<!Doctype html>");
        writer.println("<html><body>");
        writer.println("<h1>Flush - Application Managed</h1>");
        
        // Erzegung eines Studenten + Adresse
        Address address = new Address("Manchinger Straße", "20a", "85051", "Ingolstadt");
        List<Address> addresses = new ArrayList<Address>();
        addresses.add(address);
        Student student = new Student("Max", "Mustermann", "Max.Mustermann@max.de", addresses);
        
        try {
            userTransaction.begin();
            entityManager.persist(student);   
            /*
             * flush()
             * Durch flush() wird dem Datenbankmanagementsystem bereits signalisiert, dass die Objekte
             * persistiert werden sollen. Beispielweise würde eine vergebene ID nicht an ein anderes
             * zu persistierendes Objekt gegeben werden. rollback() würde denoch zum verhindern eines
             * Schreibvorganges (bzw. zum zurücknehmen des Schreibvorganges) führen.
             */
            entityManager.flush();
            userTransaction.commit();
            
        } catch(Exception e){
            try {
                userTransaction.rollback(); 
            } catch(Exception e1) {
                e.printStackTrace();
            }
            throw new ServletException(e.getMessage());
        }finally {
            entityManager.close();
        }
        writer.println("</html></body>");
	}

}
