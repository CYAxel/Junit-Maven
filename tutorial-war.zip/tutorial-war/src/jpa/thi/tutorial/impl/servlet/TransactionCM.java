package jpa.thi.tutorial.impl.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jpa.thi.tutorial.common.repository.EntityManagerRepository;
import jpa.thi.university.common.model.Address;
import jpa.thi.university.common.model.Student;

/**
 * Servlet implementation class TransactionCM
 */
@WebServlet("/transaction/cm")
public class TransactionCM extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	@Inject
    EntityManagerRepository entityManagerRepository;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    final PrintWriter writer = response.getWriter();
        writer.println("<!Doctype html>");
        writer.println("<html><body>");
        
        writer.println("<h1>Transaction (Entity Manager) Container Managed</h1>");
        
        // Erzegung eines Studenten + Adresse
        Address address = new Address("Manchinger Straße", "20a", "85051", "Ingolstadt");
        List<Address> addresses = new ArrayList<Address>();
        addresses.add(address);
        Student student = new Student("Max", "Mustermann", "Max.Mustermann@max.de", addresses);
        writer.println("<br/>ID von Student vor dem persistieren: " + student.getId());
        
        // Neu Zuweisung des Studenten, damit die ID gesetzt ist
        student = entityManagerRepository.persist(student);
        
        writer.println("<br/>Student erfolgreich angelegt");
        writer.println("<br/>Automatisch erzeugte ID, nach dem persistieren: " + student.getId());
        writer.println("<br/>" + student);
        
        writer.println("</html></body>");
	}

}
