package jpa.thi.tutorial.impl.servlet.am;

import java.io.IOException;
import java.io.PrintWriter;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jpa.thi.university.common.model.Student;

@WebServlet("/reference/am")
public class ReferenceAM extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@PersistenceUnit
    private EntityManagerFactory entityManagerFactory;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    EntityManager entityManager = entityManagerFactory.createEntityManager();
        
        final PrintWriter writer = response.getWriter();
        writer.println("<!Doctype html>");
        writer.println("<html><body>");
        writer.println("<h1>Referenz - Application Managed</h1>");
        
        Student student = null;
        int studentId = 1;
        
        try {
            /*
             * getReference()
             * Hierbei wird lediglich die Referenz zu dem Objekt aus der Datenbank geholt.
             * Die Objekt-Attribute werden noch nicht geladen.
             * Erst sobald die Attribute benötigt werden, werden diese aus der Datenbank extrahiert.
             */
            student = entityManager.getReference(Student.class, studentId);
            writer.println("<br/>Referenz gefunden:");
            writer.println("<br/>" + student);
        } catch(Exception e){
            throw new ServletException(e.getMessage());
        }finally {
            entityManager.close();
        }
        
        writer.println("</html></body>");
	}

}
