package jpa.thi.tutorial.impl.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;

import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jpa.thi.tutorial.common.repository.EntityManagerRepository;

/**
 * Servlet implementation class EntityManagerCreate
 */
@WebServlet("/entitymanager")
public class EntityManagerCM extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	@Inject
	EntityManagerRepository entityManagerRepository;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    final PrintWriter writer = response.getWriter();
        writer.println("<!Doctype html>");
        writer.println("<html><body>");
        
        writer.println("<h1>Entity Manager Container Managed</h1>");
        writer.println("<br/>Connected: " +  entityManagerRepository.isOpen());
        Map<String, Object> props = entityManagerRepository.getProperties();
        props.forEach((key, value) -> {
            writer.println("<br/>" + key + ": " + value);
        });
        
        writer.println("</html></body>");
	}

}
